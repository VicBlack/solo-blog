title: 我在 GitHub 上的开源项目
date: '2019-12-09 15:28:44'
updated: '2019-12-09 15:28:44'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [SteamCaculator](https://github.com/VicBlack/SteamCaculator) <kbd title="主要编程语言">C#</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/VicBlack/SteamCaculator/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/VicBlack/SteamCaculator/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/VicBlack/SteamCaculator/network/members "分叉数")</span>

Caculate the EX and LV in Steam.



---

### 2. [FolderDivider](https://github.com/VicBlack/FolderDivider) <kbd title="主要编程语言">C#</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/VicBlack/FolderDivider/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/VicBlack/FolderDivider/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/VicBlack/FolderDivider/network/members "分叉数")</span>

文件夹随机划分工具



---

### 3. [Unet2d](https://github.com/VicBlack/Unet2d) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/VicBlack/Unet2d/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/VicBlack/Unet2d/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/VicBlack/Unet2d/network/members "分叉数")</span>



